from collections import deque
import random
import statistics

ALGORITHM_INFO = {
    "FCFS": {"Paradigm":"Queue-based", "Typical behavior":"Simple arrival-order baseline"},
    "SJF (non-preemptive)": {"Paradigm":"Greedy selection", "Typical behavior":"Favors short CPU bursts; may delay long tasks"},
    "Priority (non-preemptive)": {"Paradigm":"Priority-based greedy", "Typical behavior":"Favors high-priority tasks; may starve low priorities"},
    "Round Robin": {"Paradigm":"Time slicing", "Typical behavior":"Shares CPU in configurable quanta"},
    "Adaptive selector": {"Paradigm":"Rule-based adaptive policy", "Typical behavior":"Selects a baseline policy from workload characteristics"},
}

REQUIRED = ["task", "arrival_time", "burst_time", "memory_mb", "priority"]

def normalize_workload(rows):
    if hasattr(rows, "to_dict"):
        rows = rows.to_dict("records")
    if not rows:
        raise ValueError("Workload must contain at least one task.")
    normalized = []
    for i, row in enumerate(rows, 1):
        missing = [c for c in REQUIRED if c not in row]
        if missing:
            raise ValueError("Missing required columns: " + ", ".join(missing))
        item = {
            "task": str(row["task"]),
            "arrival_time": int(row["arrival_time"]),
            "burst_time": int(row["burst_time"]),
            "memory_mb": int(row["memory_mb"]),
            "priority": int(row["priority"]),
        }
        if item["arrival_time"] < 0 or item["burst_time"] <= 0 or item["memory_mb"] <= 0 or item["priority"] <= 0:
            raise ValueError("Arrival time must be >= 0; burst, memory and priority must be positive.")
        normalized.append(item)
    return normalized

def generate_workload(n, seed=42):
    rng = random.Random(seed)
    rows = []
    for i in range(n):
        rows.append({
            "task": f"Task-{i+1:02d}",
            "arrival_time": rng.randint(0, max(1, n//3)),
            "burst_time": rng.randint(1, 20),
            "memory_mb": rng.randint(128, 2048),
            "priority": rng.randint(1, 5),
        })
    return rows

def _nonpreemptive(tasks, mode):
    remaining = tasks[:]
    now = 0
    schedule = []
    gantt = []
    while remaining:
        ready = [t for t in remaining if t["arrival_time"] <= now]
        if not ready:
            next_arrival = min(t["arrival_time"] for t in remaining)
            now = next_arrival
            ready = [t for t in remaining if t["arrival_time"] <= now]
        if mode == "fcfs":
            chosen = min(ready, key=lambda t: (t["arrival_time"], tasks.index(t)))
        elif mode == "sjf":
            chosen = min(ready, key=lambda t: (t["burst_time"], t["arrival_time"]))
        else:
            chosen = min(ready, key=lambda t: (t["priority"], t["arrival_time"]))
        start = now
        finish = start + chosen["burst_time"]
        schedule.append(_record(chosen, start, finish))
        gantt.append(chosen["task"])
        now = finish
        remaining.remove(chosen)
    return schedule, gantt

def _round_robin(tasks, quantum):
    pending = sorted(tasks, key=lambda t: t["arrival_time"])
    q = deque()
    rem = {t["task"]: t["burst_time"] for t in tasks}
    first_start = {}
    finish_times = {}
    now = 0
    i = 0
    schedule = []
    gantt = []
    while i < len(pending) or q:
        if not q and i < len(pending) and now < pending[i]["arrival_time"]:
            now = pending[i]["arrival_time"]
        while i < len(pending) and pending[i]["arrival_time"] <= now:
            q.append(pending[i]); i += 1
        task = q.popleft()
        first_start.setdefault(task["task"], now)
        run = min(quantum, rem[task["task"]])
        start, finish = now, now + run
        schedule.append({"Task":task["task"], "Start":start, "Finish":finish,
                         "Burst":task["burst_time"], "Memory (MB)":task["memory_mb"],
                         "Priority":task["priority"], "Arrival":task["arrival_time"]})
        gantt.append(task["task"])
        now = finish
        rem[task["task"]] -= run
        while i < len(pending) and pending[i]["arrival_time"] <= now:
            q.append(pending[i]); i += 1
        if rem[task["task"]] > 0:
            q.append(task)
        else:
            finish_times[task["task"]] = finish
    # For RR metrics, use first dispatch and final completion per task.
    final_rows = []
    for t in tasks:
        final_rows.append({
            "Task":t["task"], "Start":first_start[t["task"]],
            "Finish":finish_times[t["task"]], "Burst":t["burst_time"],
            "Memory (MB)":t["memory_mb"], "Priority":t["priority"], "Arrival":t["arrival_time"]
        })
    return final_rows, schedule, gantt

def _record(task, start, finish):
    return {"Task":task["task"], "Start":start, "Finish":finish,
            "Burst":task["burst_time"], "Memory (MB)":task["memory_mb"],
            "Priority":task["priority"], "Arrival":task["arrival_time"]}

def _metrics(schedule, tasks, capacity):
    rows = []
    for row in schedule:
        turnaround = row["Finish"] - row["Arrival"]
        waiting = turnaround - row["Burst"]
        rows.append((waiting, turnaround))
    n = len(tasks)
    makespan = max(r["Finish"] for r in schedule) - min(t["arrival_time"] for t in tasks)
    total_burst = sum(t["burst_time"] for t in tasks)
    return {
        "Algorithm": "",
        "Average waiting": round(statistics.mean(x[0] for x in rows), 2),
        "Average turnaround": round(statistics.mean(x[1] for x in rows), 2),
        "Makespan": round(makespan, 2),
        "Throughput": round(n / makespan, 4) if makespan else 0,
        "CPU busy (%)": round(100 * total_burst / makespan, 2) if makespan else 0,
        "Memory-feasible tasks": sum(t["memory_mb"] <= capacity for t in tasks),
    }

def choose_adaptive(tasks):
    bursts = [t["burst_time"] for t in tasks]
    priorities = [t["priority"] for t in tasks]
    cv = (statistics.pstdev(bursts) / statistics.mean(bursts)) if statistics.mean(bursts) else 0
    priority_spread = max(priorities) - min(priorities)
    if priority_spread >= 3:
        return "Priority (non-preemptive)"
    if cv >= 0.65:
        return "SJF (non-preemptive)"
    if len(tasks) >= 12:
        return "Round Robin"
    return "FCFS"

def run_scheduler(name, tasks, quantum=4, memory_capacity=4096):
    tasks = normalize_workload(tasks)
    selected = choose_adaptive(tasks) if name == "Adaptive selector" else name
    if selected == "FCFS":
        schedule, gantt = _nonpreemptive(tasks, "fcfs")
    elif selected == "SJF (non-preemptive)":
        schedule, gantt = _nonpreemptive(tasks, "sjf")
    elif selected == "Priority (non-preemptive)":
        schedule, gantt = _nonpreemptive(tasks, "priority")
    elif selected == "Round Robin":
        schedule, rr_slices, gantt = _round_robin(tasks, quantum)
        schedule = rr_slices
    else:
        raise ValueError(f"Unknown algorithm: {selected}")
    # RR schedule has time-slice rows; aggregate per task to compute metrics consistently.
    if name == "Round Robin":
        metrics_schedule, _, _ = _round_robin(tasks, quantum)
    else:
        metrics_schedule = schedule
    metrics = _metrics(metrics_schedule, tasks, memory_capacity)
    metrics["Algorithm"] = name if name != "Adaptive selector" else f"Adaptive → {selected}"
    return {"algorithm": metrics["Algorithm"], "schedule": schedule, "gantt": gantt, "metrics": metrics}
