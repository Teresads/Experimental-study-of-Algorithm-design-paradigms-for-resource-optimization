# PROJECT REPORT
## REAL-TIME RESOURCE MONITORING AND ADAPTIVE TASK SCHEDULING USING ALGORITHM DESIGN PARADIGMS

### Abstract
Modern computing systems execute multiple tasks while operating under limited processing and memory resources. Inefficient task scheduling can increase waiting time, turnaround time and resource contention. This project presents an interactive Python-based prototype that combines live host-resource monitoring with controlled experiments on task-scheduling algorithms. The monitoring module collects CPU utilization, RAM usage, disk utilization and process information using the psutil library. A separate workload simulator accepts built-in tasks, generated workloads or user-uploaded CSV data. It compares First-Come First-Served (FCFS), non-preemptive Shortest Job First (SJF), non-preemptive Priority Scheduling and Round Robin. A rule-based adaptive selector chooses one of these baseline policies using workload characteristics. The dashboard reports average waiting time, average turnaround time, makespan, throughput and CPU busy percentage, and provides interactive visualizations and CSV exports. The system is intended as an educational and experimental platform. Live monitoring is observational; scheduling experiments are simulated and do not modify the operating system scheduler.

**Keywords:** Operating systems, task scheduling, resource monitoring, FCFS, SJF, priority scheduling, Round Robin, adaptive scheduling, Streamlit, Python.

### 1. Introduction
Computer systems execute tasks with different processing requirements, priorities and memory demands. Scheduling algorithms determine the order in which tasks receive CPU time. Different algorithms produce different waiting times, turnaround times and fairness characteristics. This project provides a common experimental environment to compare scheduling methods while also showing the current resource state of the host computer.

### 2. Problem statement
Given a workload of tasks with arrival time, CPU burst time, memory estimate and priority, compare scheduling algorithms under identical input conditions. The system should collect live CPU/RAM/disk information and provide an interactive dashboard for workload analysis. The scheduling experiment is a simulation and is not an operating-system scheduler replacement.

### 3. Objectives
- Monitor current CPU, RAM and disk utilization.
- Display selected process information.
- Accept built-in, generated and user-uploaded task workloads.
- Implement and compare multiple scheduling algorithms.
- Evaluate waiting time, turnaround time, makespan, throughput and CPU busy percentage.
- Provide visual analytics and downloadable experiment results.

### 4. System modules
1. **Live monitoring:** Uses psutil to retrieve CPU, virtual memory, disk and process statistics.
2. **Dataset management:** Loads a built-in workload, generates deterministic random workloads or accepts CSV upload.
3. **Workload editor:** Allows task attributes to be edited before the experiment.
4. **Scheduling engine:** Implements FCFS, non-preemptive SJF, non-preemptive Priority and Round Robin.
5. **Adaptive selector:** Applies explicit rules to choose a baseline algorithm based on task count, burst-time variation and priority spread.
6. **Analytics and export:** Displays performance metrics, charts and CSV downloads.

### 5. Algorithms
**5.1 FCFS:** Tasks are executed in arrival order. It is simple but can suffer from the convoy effect.

**5.2 SJF (non-preemptive):** Among tasks that have arrived, the task with the shortest CPU burst is selected. It can reduce average waiting time but may delay long tasks.

**5.3 Priority (non-preemptive):** The available task with the highest priority is selected. In this implementation, priority 1 is the highest. Low-priority tasks may experience starvation.

**5.4 Round Robin:** Each ready task receives CPU time up to a configurable quantum. An unfinished task returns to the end of the ready queue. A small quantum improves responsiveness but increases context-switch overhead in real systems; this simulator does not model context-switch cost.

**5.5 Adaptive selector:** A transparent rule-based baseline selects among SJF, Priority, Round Robin and FCFS. It chooses Priority when priority spread is high, SJF when burst-time coefficient of variation is high, Round Robin for larger workloads with less variation, and FCFS otherwise. This is a heuristic baseline, not a claim of a novel optimal algorithm.

### 6. Performance metrics
- **Waiting time:** Total time a task spends waiting in the ready queue, calculated as turnaround time minus CPU burst time for this single-burst model.
- **Turnaround time:** Completion time minus arrival time.
- **Makespan:** Time from the earliest arrival to the final completion.
- **Throughput:** Number of completed tasks divided by makespan.
- **CPU busy percentage:** Total CPU burst duration divided by makespan. It is a simulated single-CPU measure, not live host CPU utilization.
- **Live CPU/RAM/disk:** Snapshot values collected independently from the host machine.

### 7. Experimental methodology
Use the same workload for every algorithm. Run experiments on the built-in sample, generated workloads of increasing sizes, and a user-provided CSV trace. Vary the Round Robin quantum and observe its effect. For formal reporting, repeat each workload experiment several times if randomized workloads are used; report mean and standard deviation. Keep the workload and hardware/software environment documented. Do not compare a live CPU percentage directly with the simulated CPU busy percentage.

### 8. Expected observations
- FCFS is easy to implement but a long task near the front can delay short tasks.
- SJF can improve average waiting time for known CPU burst lengths but may disadvantage long jobs.
- Priority scheduling favors critical tasks but can starve lower-priority jobs.
- Round Robin shares CPU time more fairly, with behavior affected by the time quantum.
- The adaptive selector may perform differently across workload types; it must be evaluated rather than assumed to be superior.

Actual numeric results must be generated by running the dashboard. Do not insert invented performance values into the final report.

### 9. Limitations
The prototype models one CPU and one CPU burst per task. It does not model I/O blocking, multiple cores, context-switch overhead, preemptive priority/SJF, shared memory, or actual OS-level process control. The memory budget is used for a per-task feasibility count, not a complete memory-allocation optimizer. Live resource readings refer to the machine running the app.

### 10. Future work and possible research contribution
Potential extensions include:
- Multi-core scheduling simulation.
- Memory-aware joint scheduling with aggregate memory constraints.
- Aging to reduce priority starvation.
- Context-switch overhead and I/O burst modelling.
- Workload trace parsing for a documented public cluster dataset.
- Repeated benchmark trials and confidence intervals.
- A newly specified adaptive policy, followed by ablation studies and comparison against established baselines.

A research novelty claim should only be made after reviewing current literature, defining the proposed method precisely, and demonstrating a measurable improvement on reproducible workloads.

### 11. Conclusion
The project provides a unified dashboard for observing host resource usage and comparing classical scheduling algorithms on controlled workloads. It makes scheduling trade-offs visible through metrics, timelines and charts. It can serve as a foundation for further work on memory-aware and adaptive scheduling.

### 12. Viva explanation
“Our project monitors the current CPU, RAM and disk status of the computer and separately simulates task scheduling using different algorithm design paradigms. We provide the same workload to FCFS, SJF, Priority and Round Robin, then compare waiting time, turnaround time, throughput and makespan. We also include a rule-based adaptive selector as a baseline for further research. The dashboard supports sample data, generated workloads and CSV upload. It is a decision-support and experimental tool; it does not change the operating system's actual process scheduler.”

### References
1. Silberschatz, A., Galvin, P. B., and Gagne, G. *Operating System Concepts*. Wiley.
2. Tanenbaum, A. S., and Bos, H. *Modern Operating Systems*. Pearson.
3. Python Software Foundation. Python documentation: https://docs.python.org/3/
4. Streamlit documentation: https://docs.streamlit.io/
5. psutil documentation: https://psutil.readthedocs.io/
