import platform
import time
from datetime import datetime
import psutil

def get_system_metrics():
    # Short interval gives psutil a fresh CPU utilization estimate.
    cpu = psutil.cpu_percent(interval=0.35)
    vm = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    boot = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M")
    return {
        "cpu_percent": cpu,
        "ram_percent": vm.percent,
        "ram_used_gb": round(vm.used / (1024**3), 2),
        "ram_total_gb": round(vm.total / (1024**3), 2),
        "ram_available_gb": round(vm.available / (1024**3), 2),
        "disk_percent": disk.percent,
        "disk_free_gb": round(disk.free / (1024**3), 1),
        "logical_cpus": psutil.cpu_count(logical=True) or 1,
        "boot_time": boot,
        "platform": platform.system() + " " + platform.release(),
    }

def get_process_snapshot(limit=12):
    rows = []
    for p in psutil.process_iter(["pid", "name", "memory_info", "cpu_percent"]):
        try:
            info = p.info
            mem = info.get("memory_info")
            rows.append({
                "PID": info.get("pid"),
                "Process": info.get("name") or "Unknown",
                "RAM (MB)": round(mem.rss / (1024**2), 1) if mem else 0.0,
                "CPU (%)": round(info.get("cpu_percent") or 0.0, 1),
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return sorted(rows, key=lambda x: x["RAM (MB)"], reverse=True)[:limit]
