import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from monitor import get_system_metrics, get_process_snapshot
from scheduler import run_scheduler, normalize_workload, generate_workload, ALGORITHM_INFO

st.set_page_config(page_title="Adaptive Resource Optimizer", page_icon="⚡", layout="wide")

st.markdown("""
<style>
.block-container {padding-top:1.1rem; padding-bottom:2rem; max-width:1500px;}
.hero {padding:1.5rem 1.8rem; border-radius:18px; color:white;
background:linear-gradient(115deg,#101b36,#174d69 65%,#267b83); margin-bottom:1rem;}
.hero h1 {font-size:2.1rem; margin:0 0 .35rem 0;}
.hero p {margin:0; color:#dceaf4; font-size:1rem;}
div[data-testid="stMetric"] {background:#f5f8fc; border:1px solid #e3eaf2; padding:12px 14px; border-radius:13px;}
.section-hint {color:#64748b; font-size:.9rem;}
</style>
<div class="hero">
<h1>⚡ Adaptive Resource Optimizer</h1>
<p>Real-time system monitoring · Workload scheduling · Algorithm benchmarking</p>
</div>
""", unsafe_allow_html=True)

st.sidebar.title("Control Center")
st.sidebar.caption("Configure the workload experiment")
source = st.sidebar.radio("Workload source", ["Built-in sample", "Generate workload", "Upload CSV"])
capacity = st.sidebar.number_input("Memory budget (MB) for simulation", min_value=128, max_value=65536, value=4096, step=128)
quantum = st.sidebar.number_input("Round Robin time quantum", min_value=1, max_value=100, value=4)
seed = st.sidebar.number_input("Random seed", min_value=0, max_value=999999, value=42)

sample = pd.DataFrame([
    ["Web request batch", 8, 4, 256, 3],
    ["Database query", 5, 2, 180, 2],
    ["Image processing", 14, 8, 900, 4],
    ["Backup operation", 18, 10, 700, 1],
    ["Security scan", 10, 5, 350, 5],
    ["Analytics job", 22, 12, 1100, 3],
    ["Log aggregation", 7, 3, 220, 2],
    ["Model inference", 12, 7, 800, 5],
    ["Data synchronization", 9, 4, 300, 2],
    ["Report generation", 11, 6, 450, 1],
], columns=["task","arrival_time","burst_time","memory_mb","priority"])

if source == "Built-in sample":
    workload_df = sample.copy()
elif source == "Generate workload":
    count = st.sidebar.slider("Number of tasks", 5, 100, 20)
    workload_df = pd.DataFrame(generate_workload(count, int(seed)))
else:
    upload = st.sidebar.file_uploader("Upload workload CSV", type=["csv"])
    workload_df = pd.read_csv(upload) if upload else sample.copy()
    st.sidebar.caption("Required columns: task, arrival_time, burst_time, memory_mb, priority")

try:
    workload = normalize_workload(workload_df)
except Exception as exc:
    st.error(f"Invalid workload: {exc}")
    st.stop()

st.caption(f"Loaded **{len(workload)} tasks** · Simulated memory budget: **{capacity:,} MB** · Source: **{source}**")

tab_live, tab_work, tab_compare, tab_about = st.tabs([
    "🖥️ Live System Monitor", "📋 Workload & Scheduling", "📊 Algorithm Analytics", "ℹ️ Methodology"
])

with tab_live:
    st.subheader("Live computer resource snapshot")
    st.write("This reads resource statistics from the computer running the Streamlit app. Click refresh to collect a new snapshot.")
    if st.button("↻ Refresh live metrics", type="primary"):
        st.session_state["live_metrics"] = get_system_metrics()
        st.session_state["processes"] = get_process_snapshot()
    if "live_metrics" not in st.session_state:
        st.session_state["live_metrics"] = get_system_metrics()
        st.session_state["processes"] = get_process_snapshot()
    m = st.session_state["live_metrics"]
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("CPU utilization", f'{m["cpu_percent"]:.1f}%')
    c2.metric("RAM used", f'{m["ram_percent"]:.1f}%', f'{m["ram_used_gb"]:.2f} / {m["ram_total_gb"]:.2f} GB')
    c3.metric("Disk used", f'{m["disk_percent"]:.1f}%')
    c4.metric("Logical CPUs", m["logical_cpus"])
    c5,c6,c7,c8 = st.columns(4)
    c5.metric("Available RAM", f'{m["ram_available_gb"]:.2f} GB')
    c6.metric("Disk free", f'{m["disk_free_gb"]:.1f} GB')
    c7.metric("Boot time", m["boot_time"])
    c8.metric("Platform", m["platform"])
    gauge_col1, gauge_col2 = st.columns(2)
    with gauge_col1:
        fig = go.Figure(go.Indicator(mode="gauge+number", value=m["cpu_percent"], title={"text":"CPU utilization"},
            gauge={"axis":{"range":[0,100]}, "bar":{"color":"#247ba0"}, "steps":[{"range":[0,60],"color":"#e6f4ea"},{"range":[60,85],"color":"#fff2cc"},{"range":[85,100],"color":"#fce4e4"}]}))
        st.plotly_chart(fig, use_container_width=True)
    with gauge_col2:
        fig = go.Figure(go.Indicator(mode="gauge+number", value=m["ram_percent"], title={"text":"RAM utilization"},
            gauge={"axis":{"range":[0,100]}, "bar":{"color":"#6c63a8"}, "steps":[{"range":[0,60],"color":"#e6f4ea"},{"range":[60,85],"color":"#fff2cc"},{"range":[85,100],"color":"#fce4e4"}]}))
        st.plotly_chart(fig, use_container_width=True)
    st.subheader("Top processes by RAM")
    proc = pd.DataFrame(st.session_state["processes"])
    if not proc.empty:
        st.dataframe(proc, use_container_width=True, hide_index=True)
    st.info("Live monitoring is observational only. The application does not kill, suspend, or modify operating-system processes.")

with tab_work:
    st.subheader("Workload dataset")
    st.write("Each row represents a simulated task. Burst time is required CPU time; memory is the estimated RAM demand; lower priority number means higher priority.")
    edited = st.data_editor(pd.DataFrame(workload), use_container_width=True, num_rows="dynamic",
        column_config={
            "task": st.column_config.TextColumn("Task name"),
            "arrival_time": st.column_config.NumberColumn("Arrival time", min_value=0, step=1),
            "burst_time": st.column_config.NumberColumn("CPU burst", min_value=1, step=1),
            "memory_mb": st.column_config.NumberColumn("Memory (MB)", min_value=1, step=1),
            "priority": st.column_config.NumberColumn("Priority (1 = highest)", min_value=1, step=1)
        }, key="workload_editor")
    try:
        edited_workload = normalize_workload(edited.to_dict("records"))
    except Exception as exc:
        st.error(f"Please correct the workload table: {exc}")
        st.stop()
    st.subheader("Run scheduling experiment")
    algorithms = st.multiselect("Algorithms", list(ALGORITHM_INFO.keys()),
        default=["FCFS", "SJF (non-preemptive)", "Priority (non-preemptive)", "Round Robin", "Adaptive selector"])
    run = st.button("▶ Run scheduling comparison", type="primary", use_container_width=True)
    if run:
        results = []
        for name in algorithms:
            results.append(run_scheduler(name, edited_workload, int(quantum), int(capacity)))
        st.session_state["schedule_results"] = results
        st.session_state["experiment_workload"] = edited_workload
    if "schedule_results" in st.session_state:
        results = st.session_state["schedule_results"]
        st.subheader("Scheduling output")
        summary = pd.DataFrame([r["metrics"] for r in results])
        best = min(results, key=lambda r: r["metrics"]["Average turnaround"])
        a,b,c,d = st.columns(4)
        a.metric("Algorithms compared", len(results))
        b.metric("Tasks scheduled", len(edited_workload))
        c.metric("Lowest avg turnaround", f'{best["metrics"]["Average turnaround"]:.2f}')
        d.metric("Memory budget", f'{capacity:,} MB')
        st.dataframe(summary, use_container_width=True, hide_index=True)
        for r in results:
            with st.expander(f'{r["algorithm"]} — schedule timeline'):
                st.dataframe(pd.DataFrame(r["schedule"]), use_container_width=True, hide_index=True)
                st.caption(f'Gantt sequence: {" → ".join(r["gantt"])}')
        st.download_button("⬇ Download scheduling comparison CSV", summary.to_csv(index=False).encode(),
            "scheduling_comparison.csv", "text/csv")
        schedules = []
        for r in results:
            for item in r["schedule"]:
                schedules.append({"Algorithm":r["algorithm"], **item})
        if schedules:
            st.download_button("⬇ Download detailed schedules CSV", pd.DataFrame(schedules).to_csv(index=False).encode(),
                "detailed_schedules.csv", "text/csv")

with tab_compare:
    st.subheader("Algorithm performance analytics")
    if "schedule_results" not in st.session_state:
        st.info("Run an experiment in the Workload & Scheduling tab to see analytics.")
    else:
        results = st.session_state["schedule_results"]
        df = pd.DataFrame([r["metrics"] for r in results])
        metric = st.selectbox("Choose performance metric", ["Average waiting", "Average turnaround", "Makespan", "Throughput", "CPU busy (%)", "Memory-feasible tasks"])
        fig = px.bar(df, x="Algorithm", y=metric, color="Algorithm", title=f"{metric} comparison", text_auto=".2f")
        fig.update_layout(showlegend=False, xaxis_title="")
        st.plotly_chart(fig, use_container_width=True)
        fig = px.scatter(df, x="Average waiting", y="Average turnaround", size="Throughput",
            color="Algorithm", hover_name="Algorithm", title="Waiting-time vs turnaround trade-off")
        st.plotly_chart(fig, use_container_width=True)
        st.subheader("Interpretation guide")
        st.markdown("""
        - **Waiting time:** time a task spends in the ready queue before it starts.
        - **Turnaround time:** completion time minus arrival time.
        - **Makespan:** time at which the final scheduled task completes.
        - **Throughput:** number of completed tasks per unit of makespan.
        - **CPU busy (%):** total CPU burst time divided by makespan, for this single-CPU simulation.
        - **Memory-feasible tasks:** tasks whose individual memory demand does not exceed the configured simulation budget.
        """)
        st.warning("These are simulated single-CPU scheduling results. Live CPU/RAM readings are collected separately and are not used to claim that the app controls the operating system scheduler.")

with tab_about:
    st.subheader("Project purpose")
    st.markdown("""
    **Research question:** How do different scheduling paradigms perform when the same task workload is evaluated under identical conditions?

    **Implemented methods**
    - FCFS: first-come, first-served.
    - SJF: shortest available CPU burst first (non-preemptive).
    - Priority: highest priority first, where 1 is highest (non-preemptive).
    - Round Robin: time-sliced scheduling using a configurable quantum.
    - Adaptive selector: chooses one of the implemented methods using transparent workload rules.

    **Adaptive selector rules**
    - If CPU-burst lengths vary substantially, choose SJF.
    - If priority spread is high, choose Priority scheduling.
    - If task count is large and burst lengths are relatively even, choose Round Robin.
    - Otherwise, choose FCFS.

    This selector is a baseline rule-based policy, not a newly proven optimal algorithm. A research novelty claim requires a clearly specified improvement and repeated comparison against relevant literature.
    """)
    st.subheader("Algorithm reference")
    ref = pd.DataFrame([{"Algorithm":k, **v} for k,v in ALGORITHM_INFO.items()])
    st.dataframe(ref, use_container_width=True, hide_index=True)
    st.subheader("Limitations")
    st.markdown("""
    - Live metrics describe the host running this dashboard; if deployed remotely, they describe the server, not the visitor's laptop.
    - Scheduling experiments use a synthetic task model and do not change real OS process scheduling.
    - Memory demand is treated as a per-task estimate; this prototype does not model memory sharing, I/O blocking, multiple CPU cores, or preemption except Round Robin.
    - Adaptive selection uses transparent heuristics and must be experimentally validated.
    """)
