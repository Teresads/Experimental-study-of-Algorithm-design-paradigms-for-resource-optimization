import unittest
from scheduler import run_scheduler, normalize_workload

class SchedulingTests(unittest.TestCase):
    def setUp(self):
        self.tasks = [
            {"task":"A","arrival_time":0,"burst_time":5,"memory_mb":100,"priority":2},
            {"task":"B","arrival_time":1,"burst_time":2,"memory_mb":150,"priority":1},
            {"task":"C","arrival_time":2,"burst_time":1,"memory_mb":80,"priority":3},
        ]

    def test_all_algorithms_return_metrics(self):
        for algorithm in ["FCFS","SJF (non-preemptive)","Priority (non-preemptive)","Round Robin","Adaptive selector"]:
            result = run_scheduler(algorithm, self.tasks, quantum=2, memory_capacity=500)
            self.assertEqual(len(result["metrics"]), 7)
            self.assertGreaterEqual(result["metrics"]["Average turnaround"], 0)

    def test_bad_input_rejected(self):
        with self.assertRaises(ValueError):
            normalize_workload([{"task":"bad","arrival_time":0,"burst_time":0,"memory_mb":10,"priority":1}])

if __name__ == "__main__":
    unittest.main()
