# Adaptive Resource Optimizer

A Python/Streamlit educational prototype for live host monitoring and comparative task-scheduling experiments.

## Features
- Live CPU, RAM, disk and logical CPU snapshot using `psutil`.
- Top processes by RAM.
- Built-in, generated and uploaded CSV workloads.
- Editable task table.
- FCFS, non-preemptive SJF, non-preemptive Priority, Round Robin and a transparent rule-based adaptive selector.
- Waiting time, turnaround time, makespan, throughput and CPU busy percentage.
- Interactive Plotly charts and CSV exports.

## Requirements
- Python 3.9+
- Windows, macOS or Linux
- Internet access for initial package installation

## Windows / VS Code setup
1. Extract the ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal > New Terminal.
4. Optional virtual environment:
   `py -m venv .venv`
   `.venv\Scripts\activate`
5. Install:
   `py -m pip install -r requirements.txt`
6. Run:
   `py -m streamlit run app.py`
7. Open the local URL shown in the terminal (normally `http://localhost:8501`).

If `py` is unavailable, use `python` instead.

## CSV format
Your CSV must contain these exact column names:
- `task` — task name
- `arrival_time` — integer arrival time, >= 0
- `burst_time` — positive integer CPU burst duration
- `memory_mb` — positive integer estimated memory demand
- `priority` — positive integer; 1 is highest priority

A sample file, `sample_workload.csv`, is included.

## Important interpretation
- Live system monitoring reads the machine on which Streamlit is running. When hosted on a remote server, it reports the server's resources, not the visitor's local computer.
- Scheduling algorithms run on a simulated single-CPU workload. They do not change the real operating-system scheduler or control running applications.
- Memory-feasible task count is a per-task check against the configured budget; it is not a full multi-task memory packing solution.
- Adaptive selector is a rule-based baseline, not a proven novel or optimal algorithm. Research novelty requires a clearly defined new method, reproducible experiments, and literature comparison.
- The Round Robin timeline displays each time slice; per-task waiting and turnaround metrics are calculated from first dispatch and final completion.

## Suggested experiment
1. Select Built-in sample.
2. Run all five algorithms.
3. Compare average waiting and turnaround time.
4. Change Round Robin quantum from 4 to 2 and 6.
5. Generate a 30-task workload and repeat.
6. Upload your own CSV and test.
7. Export the summary and detailed schedule.

## Unit tests
Run:
`py -m unittest test_scheduler.py`

## Research report
See `PROJECT_REPORT.md` for the problem definition, methodology, metrics, limitations, suggested contribution and viva explanation.
